se
    // {
    //     printf("***sorry you are not eligibl for insourance***");
    // }