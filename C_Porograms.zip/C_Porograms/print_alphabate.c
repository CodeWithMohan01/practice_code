#include<stdio.h>
#include<conio.h>

void main() {
    char c;
    for (int i = 65; i < 91; i++)
    {
        printf("%c \n", i);
    }
    
}
