#include<stdio.h>
#include<conio.h>

void main() {
    int n;
    for(n=1; n<=10; n++)
    printf("%d \t",n);
    printf("\n");
    for(n=10; n>=1; n--)
    printf("%d \t",n);

}
