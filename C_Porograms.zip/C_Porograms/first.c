#include<stdio.h>
#include<conio.h>
int main()
{
 
 getch();
}
